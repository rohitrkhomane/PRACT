import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class FactorialImpl extends UnicastRemoteObject implements FactorialInterface {
    public FactorialImpl() throws RemoteException {
        super();
    }

    public int factorial(int n) throws RemoteException {
        int result = 1;
        for (int i = 1; i <= n; i++) {
            result *= i;
        }
        return result;
    }
}
