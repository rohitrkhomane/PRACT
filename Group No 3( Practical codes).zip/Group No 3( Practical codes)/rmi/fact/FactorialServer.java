import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class FactorialServer {
    public static void main(String args[]) {
        try {
            // Create and export a registry on the default port (1099)
            LocateRegistry.createRegistry(1099);

            // Instantiate the remote object
            FactorialImpl obj = new FactorialImpl();

            // Bind the remote object to the registry
            Naming.rebind("//localhost/FactorialService", obj);

            System.out.println("FactorialService bound in registry");
        } catch (Exception e) {
            System.err.println("FactorialService exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
