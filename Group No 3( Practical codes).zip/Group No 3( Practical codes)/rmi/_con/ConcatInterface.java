import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ConcatInterface extends Remote {
    public String concat(String s1, String s2) throws RemoteException;
}

