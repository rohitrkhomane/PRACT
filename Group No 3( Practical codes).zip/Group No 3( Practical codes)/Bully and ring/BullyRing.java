import java.util.Scanner;
import java.util.Arrays;
import java.util.Random;
import java.util.List;
import java.util.ArrayList;

public class BullyRing {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int[] array = null;
        
        boolean running = true;
        int co=0;
       
        int index=0;
        while (running) {

                    System.out.println("Choose an option:");
                    System.out.println("1. Create");
                    System.out.println("2. Crash");
                    System.out.println("3. Display");
                    System.out.println("4. Bully");
                    System.out.println("5. Ring");
                    System.out.println("6. Exit");
                    
                    int innerChoice = input.nextInt();
                    
                    switch (innerChoice) {
                        case 1:
                            System.out.println("Enter the number of elements:");
                            int n = input.nextInt();
                            array = new int[n];
                            
                            for (int i = 0; i < n; i++) {
                                array[i] = 1;
                            }
                            break;
                        case 2:
                            if (array == null) {
                                System.out.println("The array has not been created yet.");
                            } else {
                                System.out.println("Enter the index of the element to change:");
                                index = input.nextInt();
                                System.out.println("Enter the new state of the element (0 or 1):");
                                int state = input.nextInt();
                                array[index] = state;
                            }
                            break;
                        case 3:
                            if (array == null) {
                                System.out.println("The array has not been created yet.");
                            } else {
                                System.out.println("Array:");
                                for (int i = 0; i < array.length; i++) {
                                    System.out.print("Cordinator "+i+" : "+ array[i] + " ");
                                }
                                System.out.println();
                            }
                            break;
                        case 4:
                        for (int i = 0; i < array.length; i++) {
                        Random rand = new Random();
                        co=rand.nextInt(array.length);
                        System.out.print("Selected Coordinater: "+co+" state:"+array[i]+"  \n");
                        if(array[co]==1){
                            break;
                        }else{
                            System.out.print("Selected Coordinater is crashed ........!!  \n");
                        }
                        }
                        for (int i = 0; i < array.length; i++) {
                            if(i>co){
                            System.out.print("From Coordinater "+co+" Send (Election) meassage to "+i+"\n");
                            if(array[i]==1){
                                System.out.print("Ok from "+i+"\n"); 
                            }else{
                               
                            }
                        }
                    }
                    System.out.print("Election start.....");
                        for (int j = array.length-1; j >=co ; j--) {
                            if(array[j]==1 && j !=co){
                            System.out.print("Elected Coordinator: "+j+"\n");
                            break;
                            }
                        }
                        break;
                        case 5:
                        for (int i = 0; i < array.length; i++) {
                            Random rand = new Random();
                            co=rand.nextInt(array.length);
                            System.out.print("Selected Initiater: "+co+" state:"+array[i]+"  \n");
                            if(array[co]==1){
                                break;
                            }else{
                                System.out.print("Selected Initiater is crashed ........!!  \n");
                            }
                            }
                            

                            for (int i = 0; i <= array.length; i++) {
                                if(co==array.length){
                                    co=0;
                                }
                                    if(i != index){
                                    System.out.print(co+", ");
                                    co=co+1;
                                    }
                                
                                
                            }

                            System.out.println("\nCoordinater:"+(co-1));
                            break;
                        case 6:
                            System.out.println("\nExiting...\n");
                            running = false;
                            input.close();
                            break;
                        default:
                            System.out.println("Invalid choice.\n");
                    }
                    
        }
    }
}
