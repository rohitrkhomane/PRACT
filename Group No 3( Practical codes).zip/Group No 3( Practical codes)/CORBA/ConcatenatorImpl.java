import StringConcat.ConcatenatorPOA;

class ConcatenatorImpl extends ConcatenatorPOA {
    @Override
    public String concatenate(String s1, String s2) {
        return s1 + s2;
    }
}
