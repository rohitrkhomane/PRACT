#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
  int rank, size, i, n;
  int sum = 0, local_sum = 0;
  int* array;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <n>\n", argv[0]);
    exit(1);
  }

  // Get the number of elements from the command-line argument
  n = atoi(argv[1]);

  // Initialize MPI
  MPI_Init(&argc, &argv);

  // Get the rank of the current process
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

  // Get the total number of processes
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  // Allocate memory for the array
  array = (int*) malloc(n * sizeof(int));

  // Initialize array with random values
  srand(rank + 1);
  for (i = 0; i < n; i++) {
   // array[i] = rand() % 100;
array[i]=i;
  }

  // Calculate the sum of the local portion of the array
  for (i = rank * (n / size); i < (rank + 1) * (n / size); i++) {
    local_sum += array[i];
  }

  // Print the local sum calculated by each process
  printf("Local sum for process %d: %d\n", rank, local_sum);

  // Reduce the local sums from all processes to the final sum
  MPI_Reduce(&local_sum, &sum, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

  // Print the final sum calculated by process 0
  if (rank == 0) {
    printf("Final sum: %d\n", sum);
  }

  // Free memory for the array
  free(array);

  // Finalize MPI
  MPI_Finalize();

  return 0;
}
